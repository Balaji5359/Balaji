// Function to handle booking form submission
function handleBooking() {
    // Get input values
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const date = document.getElementById('date').value;
    const tickets = document.getElementById('tickets').value;

    // Create a URL-encoded string of the booking details
    const bookingDetails = `Name=${encodeURIComponent(name)}&Email=${encodeURIComponent(email)}&Date=${encodeURIComponent(date)}&Tickets=${encodeURIComponent(tickets)}`;

    // Create a new window with the booking details
    const newWindow = window.open('', '_blank');
    
    // Write the booking confirmation to the new window
    newWindow.document.write(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Booking Confirmation</title>
        </head>
        <body>
            <h1>Booking Confirmation</h1>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Date of Visit:</strong> ${date}</p>
            <p><strong>Number of Tickets:</strong> ${tickets}</p>
        </body>
        </html>
    `);
    
    // Close the document stream to finish rendering
    newWindow.document.close();
}

// Add an event listener to the button to trigger the handleBooking function
document.getElementById('submitBtn').addEventListener('click', handleBooking);
