document.getElementById('visitor-login').addEventListener('submit', function(event) {
    event.preventDefault();
    const email = document.getElementById('visitor-email').value;
    const password = document.getElementById('visitor-password').value;
    
    // Example credentials for visitor
    const visitorEmail = 'rrbalaji2020@gmail.com';
    const visitorPassword = 'Balaji@2828';
    //alert('Visitor login submitted');
    // Implement actual authentication here
    if (email === visitorEmail && password === visitorPassword) {
        alert('Visitor login successful');
        // Redirect to visitor dashboard or booking page
        window.location.href = 'index.html';
    } 
    else {
        alert('Invalid visitor credentials');
    }
});

document.getElementById('owner-login').addEventListener('submit', function(event) {
    event.preventDefault();
    alert('Owner login submitted');
    // Implement actual authentication here
     // Example credentials for owner
     const ownerEmail = 'hero123@gmail.com';
     const ownerPassword = 'museum12345';
     
     if (email === ownerEmail && password === ownerPassword) {
         alert('Owner login successful');
         // Redirect to owner dashboard or admin panel
         window.location.href = 'index.html';
     } else {
         alert('Invalid owner credentials');
     }

});
